starter
=======

Scaffolding for standart projects
