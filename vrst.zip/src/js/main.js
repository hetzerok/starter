$(document).ready(function(){

    if(!device.mobile()) {
        $(".bg .video").html('<video autoplay="" loop="" muted=""><source src="src/video/v2.mp4" type="video/mp4"></video>');
    } else {
        $("body").addClass("mobile");
    }

    $(".typed").typed({
        strings: ["Мы создаем сайты, которые работают", "Мы создаем приложения, которые приложения"],
        loop: true,
        typeSpeed: 20,
        backDelay: 5000
    });

    $(".ham").click(function(){
        $("html, body").animate({"scrollTop": 0}, 500);
        $(".wrapper").addClass("onleft");
        $(".wrapper").removeClass("onright");
    });
    $(".times").click(function(){
        $(".wrapper").removeClass("onleft");
    });

    $(".callbacklink").click(function(){
        //if(device.mobile()) {
            $("html, body").animate({"scrollTop": 0}, 500);
            $(".wrapper").addClass("onright");
            $(".wrapper").removeClass("onleft");
        //}
        return false;
    });

});